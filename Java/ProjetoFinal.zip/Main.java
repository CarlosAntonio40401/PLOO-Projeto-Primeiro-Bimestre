package projeto;

import java.util.Scanner;

public class Main {

    public static void main(String[] args)  {

        int opcao = 0;

        Resposta r = new Resposta();
        Aluno a = new Aluno();
        Bot b = new Bot();
        Duvida d = new Duvida();
        Moderador m = new Moderador();
        Professor p = new Professor();
        Scanner leitura = new Scanner(System.in);

        do {
            //aqui Ã© um menu, para verificar o que o usuÃ¡rio irÃ¡ fazer
            System.out.println("Bem vindo!");
            System.out.println("Escolha uma opÃƒÂ§ÃƒÂ£o do menu que deseja acessar:");
            System.out.println("1 - Aluno");
            System.out.println("2 - Bot");
            System.out.println("3 - Duvida");
            System.out.println("4 - Moderador");
            System.out.println("5 - Professor");
            System.out.println("6 - Resposta");
            System.out.println("7 - Sair");
            System.out.print("Digite a opÃƒÂ§ÃƒÂ£o desejada:");
            opcao = leitura.nextInt();
            System.out.println("\n\n\n");
           
            //aqui cada opÃ§Ã£o, terÃ¡ 4 opÃ§Ãµes, aonde o usuÃ¡rio podederÃ¡ escolher entre cadastrar, procurar, modificar e deletar uma das opÃ§Ãµes
            switch (opcao) {
                //aqui Ã© para a utilizaÃ§Ã£o de aluno
                case 1:

                    switch (a.menuUsuario(opcao)) {
                        
                        case 1:
                            
                            a.registroCadastro();
                            break;
                        case 2:

                            a.alu = a.consultar(a.alu, a.getNome(), a.getCpd(), a.getEmail(), a.getSenha(), a.getTelefone());
                            break;
                        case 3:
                            a.alu=a.alterar(a.alu, a.getNome(), a.getCpd(), a.getEmail(), a.getSenha(), a.getTelefone());
                            break;
                        case 4:
                            a.alu = a.excluir(a.alu,a.getCpd());
                            break;
                        default:

                            System.out.println("Esta nÃƒÂ£o ÃƒÂ© uma opÃƒÂ§ÃƒÂ£o vÃƒÂ¡lida!");
                    }
                    break;
                //aqui Ã© para a utilizaÃ§Ã£o de BOT                    
                case 2:
                    
                    switch (b.menuBot(opcao)) {
                        case 1:
                            b.registroBot();
                            break;
                        case 2:
                            b.bot = b.consultar(b.bot, b.getPontuacao(), b.getQtndConta(), b.isAutenticador(), b.getAuxAutenticadorS(), b.getAuxAutenticadorI());
                            break;
                        case 3:
                            b.bot=b.alterar(b.bot, b.getPontuacao(), b.getQtndConta(), b.isAutenticador(), b.getAuxAutenticadorS(), b.getAuxAutenticadorI());
                            break;
                        case 4:
                            b.bot = b.excluir(b.bot,b.getPontuacao());
                            break;
                        default:

                            System.out.println("Esta nÃƒÂ£o ÃƒÂ© uma opÃƒÂ§ÃƒÂ£o vÃƒÂ¡lida!");
                    }
                    break;
                //aqui Ã© para a utilizaÃ§Ã£o de duvida                    
                case 3:
                    
                    switch (d.menuDuvida(opcao)) {
                        case 1:
                            d.registroDuvida();
                            break;
                        case 2:
                            d.duvida = d.consultar(d.duvida, d.getNomeAluno(), d.getArea(), d.getNivel(), d.getDescricao(), d.getCodigoDuvida());
                            break;
                        case 3:
                            d.duvida=d.alterar(d.duvida, d.getNomeAluno(), d.getArea(), d.getNivel(), d.getDescricao(), d.getCodigoDuvida());
                            break;
                        case 4:
                            d.duvida = d.excluir(d.duvida,d.getCodigoDuvida());
                            break;
                        default:

                            System.out.println("Esta nÃƒÂ£o ÃƒÂ© uma opÃƒÂ§ÃƒÂ£o vÃƒÂ¡lida!");
                    }
                    break;

                case 4:
                 //aqui Ã© para a utilizaÃ§Ã£o de Moderador                   
                    switch (m.menuModerador(opcao)) {
                        case 1:
                            m.registroModerador();
                            break;
                        case 2:
                            m.moderador = m.consultar(m.moderador, m.getNome(), m.getCodModerador(), m.getEmail(), m.getSenha(), m.getTelefone());
                            break;
                        case 3:
                            m.moderador=m.alterar(m.moderador, m.getNome(), m.getCodModerador(), m.getEmail(), m.getSenha(), m.getTelefone());
                            break;
                        case 4:
                            m.moderador = m.excluir(m.moderador,m.getCodModerador());

                            break;
                        default:

                            System.out.println("Esta nÃƒÂ£o ÃƒÂ© uma opÃƒÂ§ÃƒÂ£o vÃƒÂ¡lida!");
                    }
                    break;
                case 5:
                  //aqui Ã© para a utilizaÃ§Ã£o de professor                  
                    switch (p.menuProfessor(opcao)) {
                        case 1:

                            p.registroProfessor();
                            break;
                        case 2:
                            p.professor = p.consultar(p.professor, p.getNome(), p.getMatricula(), p.getEmail(), p.getSenha(), p.getTelefone());

                            break;
                        case 3:
                            p.professor=p.alterar(p.professor, p.getNome(), p.getMatricula(), p.getEmail(), p.getSenha(), p.getTelefone());
                            break;
                        case 4:
                            p.professor = p.excluir(p.professor, p.getMatricula());
                            break;
                        default:

                            System.out.println("Esta nÃƒÂ£o ÃƒÂ© uma opÃƒÂ§ÃƒÂ£o vÃƒÂ¡lida!");
                    }
                    break;
                case 6:
                    //aqui Ã© para a utilizaÃ§Ã£o de resposta(nÃ£o conseguimos implantar a parte de responder uma pergunta                   
                    switch (r.menuResposta(opcao)) {
                        case 1:
                            r.registroResposta();
                            break;
                        case 2:
                            r.resposta = r.consultar(r.resposta, r.getNomeEsclarecedor(), r.getDescricao(), r.getCodResposta(), r.getQuantidade(), r.getOrdem());
                            break;
                        case 3:
                            r.resposta=r.alterar(r.resposta, r.getNomeEsclarecedor(), r.getDescricao(), r.getCodResposta(), r.getQuantidade(), r.getOrdem());
                            break;
                        case 4:
                            r.resposta = r.excluir(r.resposta, r.getCodResposta());
                            break;

                        default:
                            System.out.println("Esta nÃƒÂ£o ÃƒÂ© uma opÃƒÂ§ÃƒÂ£o vÃƒÂ¡lida!");
                    }
            }
        } while (opcao != 7);
        
        System.out.println("Bye bye!");
    }
}
