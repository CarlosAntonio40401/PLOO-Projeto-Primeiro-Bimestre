package projeto;

import java.util.ArrayList;
import java.util.Scanner;

public class Professor {

    private String nome;
    private int matricula;
    private String email;
    private String senha;
    private String telefone;
    ArrayList<Professor> professor = new ArrayList();
    // os sets e gets de todas variaveis
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Professor() {
    }

         //aqui um construtor da classe, para informar os dados do professor
    public Professor(String nome, int matricula, String email, String senha, String telefone) {
        this.nome = nome;
        this.matricula = matricula;
        this.email = email;
        this.senha = senha;
        this.telefone = telefone;
    }
    //aqui um metodo da classe, para cadastrar um professor
    
    public ArrayList<Professor> cadastrar(ArrayList<Professor> professor, String nome, int matricula, String email, String senha, String telefone) {
        Professor p = new Professor();

        p.setNome(nome);
        p.setMatricula(matricula);
        p.setEmail(email);
        p.setSenha(senha);
        p.setTelefone(telefone);

        professor.add(p);

        System.out.println("Professor cadastrado com sucesso!");
         System.out.println("\n\n\n");
        return professor;

    }

    //aqui ele informa os dados, e passa elas para o metodo cadastrar ali em cima
    public void registroProfessor() {

        Scanner leitura = new Scanner(System.in);
        Professor p = new Professor();
                System.out.println("\n\n\n\n\n\n\n\n\n");
        System.out.println("************Cadastro Professor**************");
        System.out.println("Informe o nome do professor:");
        String nome = leitura.next();
        p.setNome(nome);
        System.out.println("Informe a matricula");
        int matricula = leitura.nextInt();
        p.setMatricula(matricula);
        System.out.println("Informe o e-mail");
        String email = leitura.next();
        p.setEmail(email);
        System.out.println("Informe a senha:");
        String senha = leitura.next();
        p.setSenha(senha);
        System.out.println("Informe o telefone:");
        String telefone = leitura.next();
        p.setTelefone(telefone);

        professor = p.cadastrar(professor, nome, matricula, email, senha, telefone);
    }

        //aqui um metodo da classe, para consultar os professor cadastrados
    public ArrayList<Professor> consultar(ArrayList<Professor> professor, String nome, int matricula, String email, String senha, String telefone) {

        for (int i = 0; i < professor.size(); i++) {
            System.out.println("\n\n\n\n\n\n\n\n\n");
            System.out.println("*********Consulta Professor*********");
            System.out.println("********Dados do professor ********");
            System.out.println("Nome: " + professor.get(i).getNome());
            System.out.println("Matricula: " + professor.get(i).getMatricula());
            System.out.println("E-mail:" + professor.get(i).getEmail());
            System.out.println("Senha: " + professor.get(i).getSenha());
            System.out.println("Telefone: " + professor.get(i).getTelefone());
            System.out.println("************************************");
            System.out.println("\n\n\n");
        }

        return professor;
    }

        //aqui um metodo da classe, para deletar um professor, informando a matricula do mesmo
    public ArrayList<Professor> excluir(ArrayList<Professor> professor,int matricula) {
       Scanner c = new Scanner(System.in);
        System.out.println("****************ExclusÃƒÂ£o do moderador********************");
        System.out.println("Informe a matricula do professor que deseja excluir:");
        matricula = c.nextInt();
        for (int i = 0; i < professor.size(); i++) {

            if (professor.get(i).getMatricula() == matricula) {
                professor.remove(i);
                System.out.println("O registro foi deletado com sucesso!");
            }
        }
        return professor;
    }
//aqui aparece as opÃ§Ãµes, do que o usuÃ¡rio vai poder fazer com a classe professor
    public int menuProfessor(int opcao) {
        Scanner leitura = new Scanner(System.in);
        System.out.println("Bem vindo as funÃƒÂ§ÃƒÂµes do Professor!");
        System.out.println("Escolha uma opÃƒÂ§ÃƒÂ£o abaixo.");
        System.out.println("1 - Cadastrar Professor");
        System.out.println("2 - Consultar Professor");
        System.out.println("3 - Alterar Professor");
        System.out.println("4 - Excluir Professor");
        System.out.print("Digite a opÃƒÂ§ÃƒÂ£o desejada:");
         opcao = leitura.nextInt();
         
         return opcao;

    }
        //aqui um metodo da classe, para alterar um professor, informando a matricula do mesmo
public ArrayList<Professor> alterar(ArrayList<Professor> professor, String nome, int matricula, String email, String senha, String telefone) {
        Scanner c = new Scanner(System.in);
                System.out.println("****************AlteraÃƒÂ§ÃƒÂ£o do Professor********************");

        System.out.println("Informe a matricula que deseja alterar:");
        matricula = c.nextInt();
        for (int i = 0; i < professor.size(); i++) {

            if (professor.get(i).getMatricula()==matricula) {
                System.out.println("Informe o novo nome:");
                professor.get(i).setNome(nome = c.next());
                System.out.println("Informe a matricula:");
                professor.get(i).setMatricula(matricula=c.nextInt());
                System.out.println("Informe o e-mail:");
                professor.get(i).setEmail(email=c.next());
                System.out.println("Informe a senha:");
                professor.get(i).setSenha(senha=c.next());
                System.out.println("Informe o telefone: ");
                professor.get(i).setTelefone(telefone=c.next());

                
                System.out.println("Alterado com Sucesso");

            }else{
                System.out.println("NÃƒÂ£o existe professor com essa matricula!");
            }
        }
        return professor;
}
}
