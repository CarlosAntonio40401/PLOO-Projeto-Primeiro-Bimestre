package projeto;

import java.util.ArrayList;
import java.util.Scanner;

public class Duvida {

    private String nomeAluno;
    private String area;
    private int nivel;
    private String descricao;
    private int codigoDuvida;
    ArrayList<Duvida> duvida = new ArrayList();
// os sets e gets de cada variavel
    public String getNomeAluno() {
        return nomeAluno;
    }

    public void setNomeAluno(String nomeAluno) {
        this.nomeAluno = nomeAluno;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getCodigoDuvida() {
        return codigoDuvida;
    }

    public void setCodigoDuvida(int codigoDuvida) {
        this.codigoDuvida = codigoDuvida;
    }

    public Duvida() {
    }
     //aqui um construtor da classe, para informar os dados da dÃºvida
    public Duvida(String nomeAluno, String area, int nivel, String descricao, int codigoDuvida) {
        this.nomeAluno = nomeAluno;
        this.area = area;
        this.nivel = nivel;
        this.descricao = descricao;
        this.codigoDuvida = codigoDuvida;
    }
     //aqui um metodo da classe, para cadastrar a duvida
    public ArrayList<Duvida> cadastrar(ArrayList<Duvida> duvida, String nomeAluno, String area, int nivel, String descricao, int codigoDuvida) {
        Duvida d = new Duvida();

        d.setNomeAluno(nomeAluno);
        d.setArea(area);
        d.setNivel(nivel);
        d.setDescricao(descricao);
        d.setCodigoDuvida(codigoDuvida);

        duvida.add(d);

        System.out.println("DÃƒÂºvida cadastrada com sucesso!");
        System.out.println("\n\n\n");
        return duvida;

    }
     //aqui um metodo da classe, para informar os dados, para cadastrar a duvida no metodo acima
    public void registroDuvida() {
        Scanner leitura = new Scanner(System.in);
        Duvida d = new Duvida();
        System.out.println("\n\n\n\n\n\n\n\n\n");
        System.out.println("************Cadastro DÃƒÂºvida**************");
        System.out.println("Informe o nome do aluno:");
        String nomeAluno = leitura.next();
        d.setNomeAluno(nomeAluno);
        System.out.println("Informe a area de dÃƒÂºvida:");
        String area = leitura.next();
        d.setArea(area);
        System.out.println("Informe  o nÃƒÂ­vel de dÃƒÂºvida:");
        int nivel = leitura.nextInt();
        d.setNivel(nivel);
        System.out.println("Informe  a descriÃƒÂ§ÃƒÂ£o da dÃƒÂºvida:");
        descricao = leitura.next();
        d.setDescricao(descricao);
        System.out.println("Informe  o cÃƒÂ³digo da dÃƒÂºvida:");
        int codigoDuvida = leitura.nextInt();
        d.setCodigoDuvida(codigoDuvida);
        duvida = d.cadastrar(duvida, nomeAluno, area, nivel, descricao, codigoDuvida);
    }
     //aqui um metodo da classe, para consultar as duvidas feitas
    public ArrayList<Duvida> consultar(ArrayList<Duvida> duvida, String nomeAluno, String area, int nivel, String descricao, int codigoDuvida) {

        for (int i = 0; i < duvida.size(); i++) {
            System.out.println("\n\n\n\n\n\n\n\n\n");
            System.out.println("*********Consulta DÃƒÂºvida*********");
            System.out.println("******** Dados da DÃƒÂºvida *********");
            System.out.println("Nome do aluno: " + duvida.get(i).getNomeAluno());
            System.out.println("ArÃƒÂ©a: " + duvida.get(i).getArea());
            System.out.println("NÃƒÂ­vel: " + duvida.get(i).getNivel());
            System.out.println("DescriÃƒÂ§ÃƒÂ£o" + duvida.get(i).getDescricao());
            System.out.println("CÃƒÂ³digo da dÃƒÂºvida:" + duvida.get(i).getCodigoDuvida());
            System.out.println("***********************************");
            System.out.println("\n\n\n");
        }
        return duvida;
    }
     //aqui um metodo da classe, para deletar uma duvida, informando o codigo da duvida
    public ArrayList<Duvida> excluir(ArrayList<Duvida> duvida, int codigoDuvida) {
        Scanner c = new Scanner(System.in);
        System.out.println("****************ExclusÃƒÂ£o do aluno********************");
        System.out.println("Informe o cÃƒÂ³digo da dÃƒÂºvida que deseja excluir:");
         codigoDuvida= c.nextInt();
        for (int i = 0; i < duvida.size(); i++) {

            if (duvida.get(i).getCodigoDuvida() == codigoDuvida) {
                duvida.remove(i);
                System.out.println("O registro foi deletado com sucesso!");
            }
        }
        return duvida;
    }
	//aqui aparece as opÃ§Ãµes, do que o usuÃ¡rio vai poder fazer com a classe Duvida
    public int menuDuvida(int opcao) {
        Scanner leitura = new Scanner(System.in);
        System.out.println("Bem vindo as funÃƒÂ§ÃƒÂµes da DÃƒÂºvida!");
        System.out.println("Escolha uma opÃƒÂ§ÃƒÂ£o abaixo.");
        System.out.println("1 - Cadastrar dÃƒÂºvida");
        System.out.println("2 - Consultar dÃƒÂºvida");
        System.out.println("3 - Alterar dÃƒÂºvida");
        System.out.println("4 - Excluir dÃƒÂºvida");
        System.out.print("Digite a opÃƒÂ§ÃƒÂ£o desejada:");
        opcao = leitura.nextInt();
        return opcao;
    }
    //aqui um metodo da classe, para alterar uma duvida ja feita, informando o codigo da duvida 
    public ArrayList<Duvida> alterar(ArrayList<Duvida> duvida, String nomeAluno, String area, int nivel, String descricao, int codigoDuvida) {
        Scanner c = new Scanner(System.in);
                System.out.println("****************AlteraÃƒÂ§ÃƒÂ£o do DÃƒÂºvida********************");

        System.out.println("Informe o cÃƒÂ³digo da dÃƒÂºvida que deseja alterar:");
        codigoDuvida = c.nextInt();
        for (int i = 0; i < duvida.size(); i++) {

            if (duvida.get(i).getCodigoDuvida() == codigoDuvida) {
                System.out.println("Informe o novo nome do aluno:");
                duvida.get(i).setNomeAluno(nomeAluno = c.next());
                System.out.println("Informe a area:");
                duvida.get(i).setArea(area = c.next());
                System.out.println("Informe o nÃƒÂ­vel:");
                duvida.get(i).setNivel(nivel = c.nextInt());
                System.out.println("Informe a descriÃƒÂ§ÃƒÂ£o:");
                duvida.get(i).setDescricao(descricao = c.next());
                System.out.println("Informe o cÃƒÂ³digo da dÃƒÂºvida:");
                duvida.get(i).setCodigoDuvida(codigoDuvida = c.nextInt());

                System.out.println("Alterado com Sucesso");

            } else {
                System.out.println("NÃƒÂ£o existe dÃƒÂºvida com esses dados!");
            }

        }
        return duvida;
    }

}
