package projeto;

import java.util.ArrayList;
import java.util.Scanner;

public class Resposta {

    private String nomeEsclarecedor;
    private String descricao;
    private int codResposta;
    private int quantidade;
    private int ordem;
    ArrayList<Resposta> resposta = new ArrayList();
    // os sets e gets de todas variaveis
    
    public String getNomeEsclarecedor() {
        return nomeEsclarecedor;
    }

    public void setNomeEsclarecedor(String nomeEsclarecedor) {
        this.nomeEsclarecedor = nomeEsclarecedor;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getCodResposta() {
        return codResposta;
    }

    public void setCodResposta(int codResposta) {
        this.codResposta = codResposta;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public int getOrdem() {
        return ordem;
    }

    public void setOrdem(int ordem) {
        this.ordem = ordem;
    }
     //aqui um construtor da classe, para informar os dados da resposta
    public Resposta(String nomeEsclarecedor, String descricao, int codResposta, int quantidade, int ordem) {
        this.nomeEsclarecedor = nomeEsclarecedor;
        this.descricao = descricao;
        this.codResposta = codResposta;
        this.quantidade = quantidade;
        this.ordem = ordem;
    }

    public Resposta() {
    }
    //aqui um metodo da classe, para cadastrar uma resposta
    
    public ArrayList<Resposta> cadastrar(ArrayList<Resposta> resposta, String nomeEsclarecedor, String descricao, int codResposta, int quantidade, int ordem) {
        Resposta r = new Resposta();

        r.setNomeEsclarecedor(nomeEsclarecedor);
        r.setDescricao(descricao);
        r.setCodResposta(codResposta);
        r.setQuantidade(quantidade);
        r.setOrdem(ordem);

        resposta.add(r);

        System.out.println("Resposta cadastrada com sucesso!");
        System.out.println("\n\n\n");
        return resposta;
    }
    //aqui ele informa os dados, e passa elas para o metodo cadastrar ali em cima
    public void registroResposta() {
        Scanner leitura = new Scanner(System.in);
        Resposta r = new Resposta();
        System.out.println("\n\n\n\n\n\n\n\n\n");
        System.out.println("*********Cadastro Respostas**************");
        System.out.println("Informe o nome do esclarecedor:");
        nomeEsclarecedor = leitura.next();
        r.setNomeEsclarecedor(nomeEsclarecedor);

        System.out.println("Informe a descriÃƒÂ§ÃƒÂ£o do fornecedor:");
        descricao = leitura.next();
        r.setDescricao(descricao);

        System.out.println("Informe o cÃƒÂ³digo da resposta:");
        codResposta = leitura.nextInt();
        r.setCodResposta(codResposta);

        System.out.println("Informe a quantidade:");
        quantidade = leitura.nextInt();
        r.setQuantidade(quantidade);

        System.out.println("Informe a ordem da resposta:");
        ordem = leitura.nextInt();
        r.setOrdem(ordem);

        resposta = r.cadastrar(resposta, nomeEsclarecedor, descricao, codResposta, quantidade, ordem);
    }
    //aqui um metodo da classe, para consultar as resposta feitas
    public ArrayList<Resposta> consultar(ArrayList<Resposta> resposta, String nomeEsclarecedor, String descricao, int codResposta, int quantidade, int ordem) {

        for (int i = 0; i < resposta.size(); i++) {
            System.out.println("\n\n\n\n\n\n\n\n\n");
            System.out.println("*********Consulta Resposta*********");
            System.out.println("********Dados da resposta *********");
            System.out.println("Nome: " + resposta.get(i).getNomeEsclarecedor());
            System.out.println("DescriÃƒÂ§ÃƒÂ£o: " + resposta.get(i).getDescricao());
            System.out.println("CÃƒÂ³digo da Resposta:" + resposta.get(i).getCodResposta());
            System.out.println("Quantidade: " + resposta.get(i).getQuantidade());
            System.out.println("Ordem: " + resposta.get(i).getOrdem());
            System.out.println("************************************");
            System.out.println("\n\n\n");
        }

        return resposta;
    }
    //aqui um metodo da classe, para deletar uma resposta, informando o codigo da resposta
    public ArrayList<Resposta> excluir(ArrayList<Resposta> resposta, int codResposta) {
        Scanner c = new Scanner(System.in);
        System.out.println("****************ExclusÃƒÂ£o da resposta********************");
        System.out.println("Informe o cÃƒÂ³digo da resposta que deseja excluir:");
        codResposta = c.nextInt();
        for (int i = 0; i < resposta.size(); i++) {

            if (resposta.get(i).getCodResposta()== codResposta) {
                resposta.remove(i);
                System.out.println("O registro foi deletado com sucesso!");
            }
        }
        return resposta;
    }
    //aqui aparece as opÃ§Ãµes, do que o usuÃ¡rio vai poder fazer com a classe resposta
    public int menuResposta(int opcao) {
        Scanner leitura = new Scanner(System.in);
        System.out.println("Bem vindo as funÃƒÂ§ÃƒÂµes da Resposta!");
        System.out.println("Escolha uma opÃƒÂ§ÃƒÂ£o abaixo.");
        System.out.println("1 - Cadastrar Respostas");
        System.out.println("2 - Consultar Respostas");
        System.out.println("3 - Alterar Resposta");
        System.out.println("4 - Excluir Resposta");
        System.out.print("Digite a opÃƒÂ§ÃƒÂ£o desejada:");
        opcao = leitura.nextInt();
        return opcao;
    }
    //aqui um metodo da classe, para deletar uma resposta, informando o codigo da resposta, para altera-la
    public ArrayList<Resposta> alterar(ArrayList<Resposta> resposta, String nomeEsclarecedor, String descricao, int codResposta, int quantidade, int ordem) {
        Scanner c = new Scanner(System.in);
        System.out.println("****************AlteraÃƒÂ§ÃƒÂ£o da Resposta********************");

        System.out.println("Informe o cÃƒÂ³digo da resposta que deseja alterar:");
        codResposta = c.nextInt();
        for (int i = 0; i < resposta.size(); i++) {

            if (resposta.get(i).getCodResposta() == codResposta) {
                System.out.println("Informe o nome do esclarecedor:");
                resposta.get(i).setNomeEsclarecedor(nomeEsclarecedor = c.next());
                System.out.println("Informe a descriÃƒÂ§ÃƒÂ£o:");
                resposta.get(i).setDescricao(descricao = c.next());
                System.out.println("Informe o cÃƒÂ³digo da resposta:");
                resposta.get(i).setCodResposta(codResposta = c.nextInt());
                System.out.println("Informe a quantidade:");
                resposta.get(i).setQuantidade(quantidade = c.nextInt());
                System.out.println("Informe a ordem:");
                resposta.get(i).setOrdem(ordem = c.nextInt());

                System.out.println("Alterado com Sucesso");

            } else {
                System.out.println("NÃƒÂ£o existe bot com esses dados!");
            }
        }
        return resposta;
    }
}
