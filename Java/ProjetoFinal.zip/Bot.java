package projeto;

import java.util.ArrayList;
import java.util.Scanner;

public class Bot {

    private int pontuacao;
    private int qtndConta;
    private boolean autenticador;
    private String auxAutenticadorS;
    private int auxAutenticadorI;
    ArrayList<Bot> bot = new ArrayList();
    // os sets e gets de todas variaveis
    
    public int getPontuacao() {
        return pontuacao;
    }

    public void setPontuacao(int pontuacao) {
        this.pontuacao = pontuacao;
    }

    public int getQtndConta() {
        return qtndConta;
    }

    public void setQtndConta(int qtndConta) {
        this.qtndConta = qtndConta;
    }

    public boolean isAutenticador() {
        return autenticador;
    }

    public void setAutenticador(boolean autenticador) {
        this.autenticador = autenticador;
    }

    public String getAuxAutenticadorS() {
        return auxAutenticadorS;
    }

    public void setAuxAutenticadorS(String auxAutenticadorS) {
        this.auxAutenticadorS = auxAutenticadorS;
    }

    public int getAuxAutenticadorI() {
        return auxAutenticadorI;
    }

    public void setAuxAutenticadorI(int auxAutenticadorI) {
        this.auxAutenticadorI = auxAutenticadorI;
    }
    //aqui um construtor da classe, para informar os dados do bot
    
    public Bot(int pontuacao, int qtndConta, boolean autenticador, String auxAutenticadorS, int auxAutenticadorI) {
        this.pontuacao = pontuacao;
        this.qtndConta = qtndConta;
        this.autenticador = autenticador;
        this.auxAutenticadorS = auxAutenticadorS;
        this.auxAutenticadorI = auxAutenticadorI;
    }

    public Bot() {
    }
    //aqui um metodo da classe, para cadastrar um aluno
    
    public ArrayList<Bot> cadastrar(ArrayList<Bot> bot, int pontuacao, int qtndConta, boolean autenticador, String auxAutenticadorS, int auxAutenticadorI) {
        Bot b = new Bot();

        b.setPontuacao(pontuacao);
        b.setQtndConta(qtndConta);
        b.setAutenticador(autenticador);
        b.setAuxAutenticadorS(auxAutenticadorS);
        b.setAuxAutenticadorI(auxAutenticadorI);

        bot.add(b);

        System.out.println("Bot cadastrado com sucesso!");
         System.out.println("\n\n\n");
        return bot;

    }
    //aqui ele informa os dados, e passa elas para o metodo cadastrar ali em cima
    public void registroBot() {
        Scanner leitura = new Scanner(System.in);
        Bot b = new Bot();
        System.out.println("\n\n\n\n\n\n\n\n\n");
        System.out.println("************Cadastro Bot**************");

        System.out.println("Informe a pontuaÃƒÂ§ÃƒÂ£o");
        int pontuacao = leitura.nextInt();
        b.setPontuacao(pontuacao);

        System.out.println("Informe a Quantidade da conta");
        int qtndConta = leitura.nextInt();
        b.setQtndConta(qtndConta);
        System.out.println("Informe a autenticaÃƒÂ§ÃƒÂ£o:");
        boolean autenticador = leitura.nextBoolean();
        b.setAutenticador(autenticador);
        System.out.println("Informe auxiliar do autenticador S:");
        String auxAutenticadorS = leitura.next();
        b.setAuxAutenticadorS(auxAutenticadorS);
        System.out.println("Informe auxiliar autenticador I:");
        int auxAutenticadorI = leitura.nextInt();
        b.setAuxAutenticadorI(auxAutenticadorI);
        bot = b.cadastrar(bot, pontuacao, qtndConta, autenticador, auxAutenticadorS, auxAutenticadorI);
    }

    //aqui um metodo da classe, para consultar os bots cadastrados 
    public ArrayList<Bot> consultar(ArrayList<Bot> bot, int pontuacao, int qtndConta, boolean autenticador, String auxAutenticadorS, int auxAutenticadorI) {

        for (int i = 0; i < bot.size(); i++) {
            System.out.println("\n\n\n\n\n\n\n\n\n");
            System.out.println("**********Consulta BOT*********");
            System.out.println("******** Dados do bot *********");
            System.out.println("PontuaÃƒÂ§ÃƒÂ£o: " + bot.get(i).getPontuacao());
            System.out.println("Qtnd conta: " + bot.get(i).getQtndConta());
            System.out.println("Autenciado: " + bot.get(i).isAutenticador());
            System.out.println("Auxiliar Autenticador I: " + bot.get(i).getAuxAutenticadorI());
            System.out.println("Auxiliar Autenticador S: " + bot.get(i).getAuxAutenticadorS());
            System.out.println("********************************");
            System.out.println("\n\n\n");
        }
        if (bot.isEmpty()) {
            System.out.println("NÃƒÂ£o existe bot cadastrado!");
            System.out.println("\n\n\n");
        }

        return bot;
    }
    //aqui um metodo da classe, para excluir o bots, informando a pontuacao 

    public ArrayList<Bot> excluir(ArrayList<Bot> bot,int pontuacao) {
        Scanner c = new Scanner(System.in);
        System.out.println("****************ExclusÃƒÂ£o do aluno********************");
        System.out.println("Informe a pontuaÃƒÂ§ÃƒÂ£o do bot que deseja excluir:");
         pontuacao= c.nextInt();
        for (int i = 0; i < bot.size(); i++) {

            if (bot.get(i).getPontuacao() == pontuacao) {
                bot.remove(i);
                System.out.println("O registro foi deletado com sucesso!");
            }
        }
        return bot;
    }

    //aqui aparece as opÃ§Ãµes, do que o usuÃ¡rio vai poder fazer com a classe professor
    public int menuBot(int opcao) {
        Scanner leitura = new Scanner(System.in);
        System.out.println("Bem vindo as funÃƒÂ§ÃƒÂµes do Bot!");
        System.out.println("Escolha uma opÃƒÂ§ÃƒÂ£o abaixo.");
        System.out.println("1 - Cadastrar bot");
        System.out.println("2 - Consultar bot");
        System.out.println("3 - Alterar bot");
        System.out.println("4 - Excluir bot");
        System.out.print("Digite a opÃƒÂ§ÃƒÂ£o desejada:");
        opcao = leitura.nextInt();
        return opcao;
    }
    //aqui um metodo da classe, para alterar os dados de um bots, informando a pontuacao 

    public ArrayList<Bot> alterar(ArrayList<Bot> bot, int pontuacao, int qtndConta, boolean autenticador, String auxAutenticadorS, int auxAutenticadorI) {
        Scanner c = new Scanner(System.in);
                System.out.println("****************AlteraÃƒÂ§ÃƒÂ£o do Bot********************");

        System.out.println("Informe a pontuaÃƒÂ§ÃƒÂ£o que deseja alterar:");
        pontuacao = c.nextInt();
        for (int i = 0; i < bot.size(); i++) {

            if (bot.get(i).getPontuacao() == pontuacao) {
                System.out.println("Informe a nova pontuaÃƒÂ§ÃƒÂ£o:");
                bot.get(i).setPontuacao(pontuacao = c.nextInt());
                System.out.println("Informe a qtnd conta:");
                bot.get(i).setQtndConta(qtndConta = c.nextInt());
                System.out.println("Informe o autenticador:");
                bot.get(i).setAutenticador(autenticador = c.nextBoolean());
                System.out.println("Informe o auxiliar autenticador S:");
                bot.get(i).setAuxAutenticadorS(auxAutenticadorS = c.next());
                System.out.println("Informe o o auxiliar autenticador i:");
                bot.get(i).setAuxAutenticadorI(auxAutenticadorI = c.nextInt());

                System.out.println("Alterado com Sucesso");

            } else {
                System.out.println("NÃƒÂ£o existe bot com esses dados!");
            }
        }

        return bot;
    }
}
