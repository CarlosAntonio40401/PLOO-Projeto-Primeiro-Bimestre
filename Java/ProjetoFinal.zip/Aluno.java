package projeto;

import java.util.ArrayList;
import java.util.Scanner;

public class Aluno {

    private String nome;
    private int cpd;
    private String email;
    private String senha;
    private String telefone;

    ArrayList<Aluno> alu = new ArrayList();
    //todos os sets e gets das variaveis de alunos
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCpd() {
        return cpd;
    }

    public void setCpd(int cpd) {
        this.cpd = cpd;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
      //aqui um construtor da classe, para informar os dados do aluno
    public Aluno(String nome, int cpd, String email, String senha, String telefone) {
        this.nome = nome;
        this.cpd = cpd;
        this.email = email;
        this.senha = senha;
        this.telefone = telefone;
    }

    public Aluno() {
    }
    //aqui um metodo da classe, para cadastrar um aluno
    
    public ArrayList<Aluno> cadastrar(ArrayList<Aluno> alu, String nome, int cpd, String email, String senha, String telefone) {
        Aluno a = new Aluno();

        a.setNome(nome);
        a.setCpd(cpd);
        a.setEmail(email);
        a.setSenha(senha);
        a.setTelefone(telefone);

        alu.add(a);

        System.out.println("Aluno cadastrado com sucesso!");
        System.out.println("\n\n\n");
        return alu;
    }
    //aqui ele informa os dados, e passa elas para o metodo cadastrar ali em cima
    public void registroCadastro() {
        Aluno a = new Aluno();
        Scanner leitura = new Scanner(System.in);
        System.out.println("************Cadastro aluno**************");

        System.out.println("Informe o nome do aluno:");
        String nome = leitura.next();
        a.setNome(nome);
        System.out.println("Informe o CPD:");
        int cpd = leitura.nextInt();
        a.setCpd(cpd);
        System.out.println("Informe o e-mail:");
        String email = leitura.next();
        a.setEmail(email);
        System.out.println("Informe a senha:");
        String senha = leitura.next();
        a.setSenha(senha);
        System.out.println("Informe o telefone:");
        String telefone = leitura.next();
        a.setTelefone(telefone);
        //aqui ele passa os dados informados no metodo para o construtor
        alu = a.cadastrar(alu, nome, cpd, email, senha, telefone);
    }
        //aqui Ã© um metodo para consultar os alunos, e os dados do mesmo
    public ArrayList<Aluno> consultar(ArrayList<Aluno> alu, String nome, int cpd, String email, String senha, String telefone) {

        for (int i = 0; i < alu.size(); i++) {

            System.out.println("\n\n\n\n\n\n\n\n\n");
            System.out.println("******Consulta Aluno********");
            System.out.println("********  Dados do Aluno ********");
            System.out.println("Nome do aluno: " + alu.get(i).getNome());
            System.out.println("CPD do aluno:" + alu.get(i).getCpd());
            System.out.println("E-mail:" + alu.get(i).getEmail());
            System.out.println("Senha: " + alu.get(i).getSenha());
            System.out.println("Telefone: " + alu.get(i).getTelefone());
            System.out.println("**********************************");
            System.out.println("\n\n\n");

        }
        //se nÃ£o existirem alunos cadastrado, irÃ¡ aparecer uma mensagem dizendo que nÃ£o hÃ¡ alunos cadastrados
        if (alu.isEmpty()) {
            System.out.println("NÃƒÂ£o existe alunos cadastrado!");
            System.out.println("\n\n\n");
        }

        return alu;
    }

    //aqui um metodo da classe, para deletar um aluno, informando o cpd do mesmo que deseja ser deletado
    public ArrayList<Aluno> excluir(ArrayList<Aluno> aluno, int cpd) {
        Scanner c = new Scanner(System.in);
        System.out.println("****************ExclusÃƒÂ£o do aluno********************");
        System.out.println("Informe o CPD do aluno que deseja excluir:");
        cpd = c.nextInt();
        for (int i = 0; i < alu.size(); i++) {

            if (alu.get(i).getCpd() == cpd) {
                aluno.remove(i);
                System.out.println("O registro foi deletado com sucesso!");
            }
        }
        return aluno;
    }
    //aqui aparece as opÃ§Ãµes, do que o usuÃ¡rio vai poder fazer com a classe Aluno
    public int menuUsuario(int opcao) {
        Scanner leitura = new Scanner(System.in);
        System.out.println("Bem vindo as funÃƒÂ§ÃƒÂµes do Aluno!");
        System.out.println("Escolha uma opÃƒÂ§ÃƒÂ£o abaixo.");
        System.out.println("1 - Cadastrar aluno");
        System.out.println("2 - Consultar aluno");
        System.out.println("3 - Alterar aluno");
        System.out.println("4 - Excluir aluno");
        System.out.print("Digite a opÃƒÂ§ÃƒÂ£o desejada:");

        opcao = leitura.nextInt();
        return opcao;
    }
     //aqui um metodo da classe, para alterar os dados de um aluno
    public ArrayList<Aluno> alterar(ArrayList<Aluno> alu, String nome, int cpd, String email, String senha, String telefone) {
        Scanner c = new Scanner(System.in);
        System.out.println("****************AlteraÃƒÂ§ÃƒÂ£o do aluno********************");
        System.out.println("Informe o nome do usuario que deseja alterar:");
        nome = c.next();
        for (int i = 0; i < alu.size(); i++) {

            if (alu.get(i).getNome().equals(nome)) {
                System.out.println("Informe o novo nome:");
                alu.get(i).setNome(nome = c.next());
                System.out.println("Informe o CPD:");
                alu.get(i).setCpd(cpd = c.nextInt());
                System.out.println("Informe o e-mail:");
                alu.get(i).setEmail(email = c.next());
                System.out.println("Informe a senha:");
                alu.get(i).setSenha(senha = c.next());
                System.out.println("Informe o telefone:");
                alu.get(i).setTelefone(telefone = c.next());

                System.out.println("Alterado com Sucesso");

            } else {
                System.out.println("NÃƒÂ£o existe alunos com esse nome!");
            }
        }

        return alu;
    }
}
