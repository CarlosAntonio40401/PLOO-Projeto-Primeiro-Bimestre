package projeto;

import java.util.ArrayList;
import java.util.Scanner;

public class Moderador {

    private String nome;
    private int codModerador;
    private String email;
    private String senha;
    private String telefone;
    ArrayList<Moderador> moderador = new ArrayList();
    // os sets e gets de todas variaveis
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCodModerador() {
        return codModerador;
    }

    public void setCodModerador(int codModerador) {
        this.codModerador = codModerador;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Moderador() {
    }

    //aqui um construtor da classe, para informar os dados da resposta
    public Moderador(String nome, int codModerador, String email, String senha, String telefone) {
        this.nome = nome;
        this.codModerador = codModerador;
        this.email = email;
        this.senha = senha;
        this.telefone = telefone;
    }
    //aqui um metodo da classe, para cadastrar um moderador
    public ArrayList<Moderador> cadastrar(ArrayList<Moderador> moderador, String nome, int codModerador, String email, String senha, String telefone) {
        Moderador m = new Moderador();

        m.setNome(nome);
        m.setCodModerador(codModerador);
        m.setEmail(email);
        m.setSenha(senha);
        m.setTelefone(telefone);

        moderador.add(m);

        System.out.println("Moderador cadastrado com sucesso!");
        System.out.println("\n\n\n");
        return moderador;

    }
    //aqui ele informa os dados, e passa elas para o metodo cadastrar ali em cima
    public void registroModerador() {
        Moderador m = new Moderador();
        Scanner leitura = new Scanner(System.in);
        System.out.println("\n\n\n\n\n\n\n\n\n");
        System.out.println("************Cadastro Moderador**************");
        System.out.println("Informe o nome do moderador:");
        String nome = leitura.nextLine();
        m.setNome(nome);
        System.out.println("Informe o cÃƒÂ³digo do moderador:");
        int codModerador = leitura.nextInt();
        m.setCodModerador(codModerador);
        System.out.println(" Informe o e-mail do moderador:");
        String email = leitura.next();
        m.setEmail(email);
        System.out.println("Informe a senha do moderador:");
        String senha = leitura.next();
        m.setSenha(senha);
        System.out.println("Informe o telefone:");
        String telefone = leitura.next();
        m.setTelefone(telefone);
        moderador = m.cadastrar(moderador, nome, codModerador, email, senha, telefone);
    }
    //aqui um metodo da classe, para consultar os moderadores cadastrados
    
    public ArrayList<Moderador> consultar(ArrayList<Moderador> moderador, String nome, int codModerador, String email, String senha, String telefone) {

        for (int i = 0; i < moderador.size(); i++) {
            System.out.println("\n\n\n\n\n\n\n\n\n");
            System.out.println("*********Consulta Resposta*********");
            System.out.println("********Dados do moderador********");
            System.out.println("Nome: " + moderador.get(i).getNome());
            System.out.println("CÃƒÂ³digo do moderador: " + moderador.get(i).getCodModerador());
            System.out.println("E-mail: " + moderador.get(i).getEmail());
            System.out.println("Senha: " + moderador.get(i).getSenha());
            System.out.println("Telefone:" + moderador.get(i).getTelefone());
            System.out.println("***********************************");
            System.out.println("\n\n\n");
        }

        return moderador;
    }
    //aqui um metodo da classe, para excluir um moderador, informando o codigo de moderador
    
    public ArrayList<Moderador> excluir(ArrayList<Moderador> moderador, int codigoModerador) {
        Scanner c = new Scanner(System.in);
        System.out.println("****************ExclusÃƒÂ£o do moderador********************");
        System.out.println("Informe o cÃƒÂ³digo de moderador que deseja excluir:");
        codigoModerador = c.nextInt();
        for (int i = 0; i < moderador.size(); i++) {

            if (moderador.get(i).getCodModerador() == codigoModerador) {
                moderador.remove(i);
                System.out.println("O registro foi deletado com sucesso!");
            }
        }
        return moderador;
    }
//aqui aparece as opÃ§Ãµes, do que o usuÃ¡rio vai poder fazer com a classe moderador
    
    public int menuModerador(int opcao) {
        Scanner leitura = new Scanner(System.in);
        System.out.println("Bem vindo as funÃƒÂ§ÃƒÂµes do Moderador!");
        System.out.println("Escolha uma opÃƒÂ§ÃƒÂ£o abaixo.");
        System.out.println("1 - Cadastrar Moderador");
        System.out.println("2 - Consultar Moderador");
        System.out.println("3 - Alterar Moderador");
        System.out.println("4 - Excluir Moderador");
        System.out.print("Digite a opÃƒÂ§ÃƒÂ£o desejada:");
        opcao = leitura.nextInt();

        return opcao;
    }
    //aqui um metodo da classe, para alterar um moderador, informando o codigo de moderador
    public ArrayList<Moderador> alterar(ArrayList<Moderador> moderador, String nome, int codModerador, String email, String senha, String telefone) {
        Scanner c = new Scanner(System.in);
        System.out.println("****************AlteraÃƒÂ§ÃƒÂ£o do Moderador********************");

        System.out.println("Informe o cÃƒÂ³digo do moderador que deseja alterar:");
        codModerador = c.nextInt();
        for (int i = 0; i < moderador.size(); i++) {

            if (moderador.get(i).getCodModerador() == codModerador) {
                System.out.println("Informe o novo nome:");
                moderador.get(i).setNome(nome = c.next());
                System.out.println("Informe o cÃƒÂ³digo do moderador:");
                moderador.get(i).setCodModerador(codModerador = c.nextInt());
                System.out.println("Informe o e-mail:");
                moderador.get(i).setEmail(email = c.next());
                System.out.println("Informe a senha:");
                moderador.get(i).setSenha(senha = c.next());
                System.out.println("Informe o telefone:");
                moderador.get(i).setTelefone(telefone = c.next());

                System.out.println("Alterado com Sucesso");

            } else {
                System.out.println("NÃƒÂ£o existe moderador com esses dados!");
            }
        }
        return moderador;
    }
}
